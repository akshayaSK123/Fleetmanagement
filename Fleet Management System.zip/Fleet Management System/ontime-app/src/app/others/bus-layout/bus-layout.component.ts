import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { faWindowClose } from '@fortawesome/free-solid-svg-icons'
@Component({
  selector: 'app-bus-layout',
  templateUrl: './bus-layout.component.html',
  styleUrls: ['./bus-layout.component.css']
})
export class BusLayoutComponent implements OnInit {
  @Output() seatLayout: EventEmitter<any> = new EventEmitter<any>();
  @Input() seats: any;
  @Input() editMode: Boolean;
  selectedSeats: any = [];
  rows = 10;
  column = 5;
  capacity;
  faWindowClose = faWindowClose;

  deleteSeat(id) {
    id = id.split(",")
    var val = this.seats[id[0]][id[1] - 1].type;
    this.seats[id[0]][id[1] - 1].type = "noseat"
    this.reArrangeSeats(id[0], id[1] - 1)
  }

  reArrangeSeats(r, c) {
    for (var i = r; i < this.rows; i++) {
      var k = i == r ? c : 0;
      for (var j = k; j < this.column; j++) {
        this.seats[i][j].seatno -= 1;
        this.capacity = this.seats[i][j].seatno;
      }
    }
    this.seatLayout.emit({ Layout: this.seats, capacity: this.capacity });
  }

  selectSeat(id) {
    id = id.split(",")
    var val = this.seats[id[0]][id[1] - 1].type;
    if (val == "selected") {
      this.seats[id[0]][id[1] - 1].type = "vacant";
      this.selectedSeats.splice(this.selectedSeats.indexOf(id[2]),1)
    }
    else if (val == "vacant") {

      this.seats[id[0]][id[1] - 1].type = "selected"
      this.selectedSeats.push(id[2])

    }

    this.seatLayout.emit(this.selectedSeats);


  }

  addSeats() {
    this.seats[this.rows] = []
    var seat_no = this.seats[this.rows - 1][this.column - 1].seatno
    for (var j = 1; j <= this.column; j++) {
      var obj = {
        "seatno": (seat_no) + j,
        "id": { "r": (this.rows), "c": j },
        "type": "vacant"
      }
      this.seats[this.rows].push(obj)
    }
    this.rows++;
    this.capacity += this.column;
    this.seatLayout.emit({ Layout: this.seats, capacity: this.capacity });

  }
  resetSeats() {
    this.rows = 10;
    this.column = 5;
    this.seats = []
    for (var i = 0; i < this.rows; i++) {
      this.seats[i] = []
      for (var j = 1; j <= this.column; j++) {
        var obj = { "seatno": (i * this.column) + j, "id": { "r": i, "c": j }, "type": "vacant" }
        this.seats[i][j - 1] = obj;
        this.capacity = obj.seatno;
      }
    }
    this.seatLayout.emit({ Layout: this.seats, capacity: this.capacity });
  }
  constructor() { }

  ngOnInit() {
    if (this.editMode == true)
      this.resetSeats()
  }
}