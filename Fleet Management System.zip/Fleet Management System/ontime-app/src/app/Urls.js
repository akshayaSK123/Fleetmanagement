var baseUrl = "http://localhost:8080";
export default {
    "addVehicle": baseUrl + "/addVehicle",
    "getLocation": baseUrl + "/getLocation",
    "addTrip": baseUrl + "/addTrip",
    "search": baseUrl + "/search",
    "getVehicle": baseUrl + "/getVehicle",
    "addBooking": baseUrl + "/addBooking",
    "getBookings":baseUrl + "/getBookings",
    "login": baseUrl + "/login",
    "adminlogin": baseUrl + "/adminlogin",
    "adminsignout": baseUrl + "/adminsignout",
    "resetPassword": baseUrl + "/resetPassword",
    "isTokenValid": baseUrl + "/isTokenValid",
    "getTrip": baseUrl + "/getTrip",
    "getDriver": baseUrl + "/getDriver",    
    "isAdminSession": baseUrl + "/isAdminSession",
    "adminlogin1": baseUrl + "/adminlogin1",
    "updPassword": baseUrl + "/updPassword",
    "addSchedule": baseUrl + "/addSchedule",
    "getUserProfile": baseUrl + "/getUser",
    "updUserProfile": baseUrl + "/updUser",
    "signout": baseUrl + "/signout",

    
    
    "addLocation": baseUrl + "/addLocation",
    "addDriver": baseUrl + "/addDriver",
    "register": baseUrl + "/register"

}
// export class Urls {}
