import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  public get router(): Router {
    return this._router;
  }
  public set router(value: Router) {
    this._router = value;
  }
  constructor(private _router: Router) { }

  ngOnInit() {
  }
  aboutus()
  {
 this.router.navigate(["/aboutus"]);
  }
  contactus()
  {
 this.router.navigate(["/contactus"]);
  }
}
