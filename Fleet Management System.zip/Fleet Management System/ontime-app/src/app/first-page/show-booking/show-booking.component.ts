import { Component, OnInit } from '@angular/core';
import 'bootstrap';
// import {NgbDate, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import Urls from '../../Urls.js';

@Component({
  selector: 'app-show-booking',
  templateUrl: './show-booking.component.html',
  styleUrls: ['./show-booking.component.css']
})
export class ShowBookingComponent implements OnInit {
  booking: any = [];
  session;

  constructor(private http: HttpClient, private router: Router) { }
  getBookings() {
    this.http.post(Urls.getBookings, {"userid":localStorage.getItem('userId')}).subscribe((resp: any) => {
      if (resp.session == true) { // checking whether the session is active or not from response
       
        this.booking = JSON.parse(resp.data);
        this.booking.forEach(bk => {
          bk.mon =  new Date(bk.dep).toLocaleDateString('en-US',{'month':'short'})
          bk.date =  new Date(bk.dep).toLocaleDateString('en-US',{'day':'2-digit'})
          bk.dep =  new Date(bk.dep).toLocaleTimeString('en-US')
          bk.arr =  new Date(bk.arr).toLocaleString('en-US')

        })
      }
      else {
        this.router.navigate(['/']);
      }
    })
  }

  

  ngOnInit() {
    var userId = window.history.state.userid ?window.history.state.userid: localStorage.getItem('userId');
    this.session = userId !="null" && userId !=""  ? true:false;
    this.getBookings();
  }

}




