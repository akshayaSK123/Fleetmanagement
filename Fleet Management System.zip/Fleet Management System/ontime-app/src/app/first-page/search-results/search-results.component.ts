import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import Urls from '../../Urls.js';
import * as $ from 'jquery';
import { NgbCalendar } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.css']
})
export class SearchResultsComponent implements OnInit {
  originId: any;
  destinationId;
  fromDate;
  endDate;
  trips: any = [];
  selectedSeats;
  tripId;
  userId;
  session=false;
  constructor(private calendar: NgbCalendar,
    private http: HttpClient,
    private router: Router,
    private route: ActivatedRoute
  ) {
  }
  loadSearchResults() {
    this.trips = [];
    var start = new Date(this.fromDate.year, this.fromDate.month - 1, this.fromDate.day)
    var end = new Date(this.fromDate.year, this.fromDate.month - 1, this.fromDate.day)
    end.setDate(end.getDate() + 1);
    console.log(start.toISOString(),end.toISOString())
    this.http.post(Urls.search, {
      "originId": this.originId, "destinationId": this.destinationId,
      "start": start.toISOString(),
      "end": end.toISOString()
    }).subscribe((resp: any) => {
      if (resp.session != false)
        var trips = JSON.parse(resp.data);
      trips.forEach(loc => {
        this.trips.push({
          "TripId": loc.TripId,
          "Dep": new Date(loc.Dep).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          "Arr": new Date(loc.Arr).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
          "Fare": loc.Fare,
          "seats": loc.seats
        })
      })
    })


  }
  redirectToLogin(){
    this.router.navigate(['/login'])
  }
  setLayout(seat) {
    console.log(seat)
    this.selectedSeats = seat;
  }
bookTickets(fare){
  this.http.post(Urls.addBooking, {
    "userid": localStorage.getItem("userId"),
    "tripid": this.tripId,
    "seats":this.selectedSeats,
    "pickuppoint":this.originId,
    "droppoint":this.destinationId,
    "totalamount":fare
  }).subscribe((resp: any) => {
    if(resp.data != "failure")
    this.router.navigate(['/bookingConfirmation/'+resp.data]);
});
}

  viewSeats(TripId) {
    this.tripId = TripId;
    this.selectedSeats = [];
  }

  ngOnInit() {
    $('.collapse').collapse('hide')
    var userId = localStorage.getItem('userId');
    this.session = userId !="null" && userId !=""  ? true:false;
   
    this.route.params.subscribe(params => {
      this.originId = params['originId'];
      this.destinationId = params['destinationId'];
      var date = params['onward'].split('/');
      this.fromDate = { "year": parseInt(date[2]), "month": parseInt(date[0]), "day": parseInt(date[1]) };
      this.loadSearchResults();
    });
  }

}
