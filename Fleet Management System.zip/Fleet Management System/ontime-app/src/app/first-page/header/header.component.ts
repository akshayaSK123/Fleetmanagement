import { Component, OnInit , Input } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import Urls from '../../Urls.js';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  @Input() mode: any;
  @Input() session:any;

  constructor(private router: Router,private http: HttpClient,) { }

  adminLogout(){
    this.http.post(Urls.adminsignout, {}).subscribe((resp: any) => {
      this.router.navigate(["/adminlogin"]);
})
  }
  signout(){
    this.http.post(Urls.signout, {}).subscribe((resp: any) => {
             this.router.navigate(["/"]);
             localStorage.setItem("userId",null)
             if(this.router.url == '/')
             window.location.reload()
      })

  }
  ngOnInit() {
  }

  login()
  {
  this.router.navigate(["/login"]);
  }
  schedules()
  {
 this.router.navigate(["/schedules"]);
  }
}
