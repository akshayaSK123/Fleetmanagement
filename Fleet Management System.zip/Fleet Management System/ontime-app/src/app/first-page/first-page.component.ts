import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import 'bootstrap';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-first-page',
  templateUrl: './first-page.component.html',
  styleUrls: ['./first-page.component.css']
})
export class FirstPageComponent implements OnInit {
  userId ;
  session = false;
  constructor() { }

  ngOnInit() {
    this.userId = window.history.state.userid ?window.history.state.userid: localStorage.getItem('userId');
    localStorage.setItem('userId', this.userId);
    console.log("UserId",this.userId,this.userId !="null" && this.userId !=""   ? true:false);
    this.session = this.userId !="null" && this.userId !=""  ? true:false;
    
  }
  ngAfterViewInit() {
    $('.carousel').carousel();
  }
}
