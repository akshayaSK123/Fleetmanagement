import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router,ActivatedRoute } from '@angular/router';
import Urls from '../../Urls.js';

@Component({
  selector: 'app-bookingconfirmed',
  templateUrl: './bookingconfirmed.component.html',
  styleUrls: ['./bookingconfirmed.component.css']
})
export class BookingconfirmedComponent implements OnInit {
bookingId;
booking:any={}
  constructor(private http: HttpClient, private router: Router, private route: ActivatedRoute) { }
  getBookings() {
    this.http.post(Urls.getBookings, {"userid":localStorage.getItem('userId'),"bookingId":this.bookingId}).subscribe((resp: any) => {
      if (resp.session == true) { // checking whether the session is active or not from response
       
        var booking = JSON.parse(resp.data);
        booking.forEach(bk => {
          bk.mon =  new Date(bk.dep).toLocaleDateString('en-US',{'month':'short'})
          bk.date =  new Date(bk.dep).toLocaleDateString('en-US',{'day':'2-digit'})
          bk.dep =  new Date(bk.dep).toLocaleTimeString('en-US')
          bk.arr =  new Date(bk.arr).toLocaleString('en-US')

        })
        this.booking = booking[0];
        this.booking.userId = localStorage.getItem('userId');
      }
      else {
        this.router.navigate(['/']);
      }
    })
  }
  ngOnInit() {
    this.route.params.subscribe(params => {
      this.bookingId = params['bookingId'];
      this.getBookings()
    })
  }

}
