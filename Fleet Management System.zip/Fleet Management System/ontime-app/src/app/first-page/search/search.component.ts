import { Component, OnInit, Input } from '@angular/core';
import * as $ from 'jquery';
import 'bootstrap';
import { faCalendar, faExchangeAlt } from '@fortawesome/free-solid-svg-icons'
// import * as moment from 'moment';
import { NgbDate, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import Urls from '../../Urls.js';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  @Input() originId: String;
  @Input() destinationId: String;
  @Input() fromDate: any;
  @Input() title: String;
  origins: any = [];
  searchParams: any = {}
  faCalender = faCalendar;
  faExchangeAlt = faExchangeAlt;
  earliestBookingDate: any;
  lastBookingDate: any;
  constructor(calendar: NgbCalendar,
    private http: HttpClient,
    private router: Router
  ) {
    //getting All Locations for dropdown
    this.http.post(Urls.getLocation, {}).subscribe((resp: any) => {
        var resporigins = JSON.parse(resp.data);
        resporigins.forEach(loc => {
          this.origins.push({ "City_State": loc.Locationcity + "," + loc.Locationstate, "id": loc.LocationID })
        })
        setTimeout(() => {
          $('.origin').selectpicker('refresh');
          $('.dest').selectpicker('refresh');
          $('.origin').selectpicker('val', this.originId ? this.originId : "");
          $('.dest').selectpicker('val', this.destinationId ? this.destinationId : "");
        }, 500);

    });

    this.earliestBookingDate = calendar.getToday();
    this.lastBookingDate = calendar.getNext(calendar.getToday(), 'd', 10);
  }

  //Swap Origin and Destination
  swap() {
    var temp = this.searchParams.originId ;
    this.searchParams.originId = this.searchParams.destinationId ;
    this.searchParams.destinationId = temp;
    $('.origin').selectpicker('val', this.searchParams.originId);
    $('.dest').selectpicker('val', this.searchParams.destinationId);
  }

  search() {
    var fromDate = this.searchParams.fromDate
    var newfromDate =  new Date(fromDate.year, fromDate.month - 1, fromDate.day).toLocaleDateString('en-US');
    this.router.navigate(['/plan', this.searchParams.originId, this.searchParams.destinationId,
    newfromDate, "ontime"]);

  }

  ngOnInit() {
      this.searchParams.fromDate = this.fromDate
      this.searchParams.originId = this.originId
      this.searchParams.destinationId = this.destinationId


  }
  ngAfterViewInit() {
    $('.selectpicker').selectpicker();
  }

}
