import { Component, OnInit } from '@angular/core';
import 'bootstrap';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import Urls from '../../Urls.js';



@Component({
  selector: 'app-add-driver',
  templateUrl: './add-driver.component.html',
  styleUrls: ['./add-driver.component.css']
})
export class AddDriverComponent implements OnInit {
  driver: any = {};
  response = false;
  constructor(private http: HttpClient){}

  addDriver() {
    //Deep copy 
    var driver = JSON.parse(JSON.stringify(this.driver));
    this.http.post(Urls.addDriver, driver).subscribe((resp: any) => {
      if(resp.data == "success")
      this.response =  true;
      this.driver={};
     })
  }


  ngOnInit() {
  }

}
