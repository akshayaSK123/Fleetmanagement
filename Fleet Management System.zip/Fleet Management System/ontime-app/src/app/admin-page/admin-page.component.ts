import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import Urls from '../Urls.js';


@Component({
  selector: 'app-admin-page',
  templateUrl: './admin-page.component.html',
  styleUrls: ['./admin-page.component.css']
})
export class AdminPageComponent implements OnInit {
 activeContent:Number;
 setActiveContent(data){
  this.activeContent=data;
}
  constructor(private router: Router, private http: HttpClient) { }

  ngOnInit() {
    this.http.post(Urls.isAdminSession, {}).subscribe((resp: any) => {
      // checking whether the session is active or not from response
      if (resp.session == false) {
        this.router.navigate(['/adminlogin/SessionExpired']);
      }
    });
  }

}
