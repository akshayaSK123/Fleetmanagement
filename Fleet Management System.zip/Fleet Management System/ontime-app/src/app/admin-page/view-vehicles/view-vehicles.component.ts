import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import Urls from '../../Urls.js';

@Component({
  selector: 'app-view-vehicles',
  templateUrl: './view-vehicles.component.html',
  styleUrls: ['./view-vehicles.component.css']
})
export class ViewVehiclesComponent implements OnInit {
all_vehicles:any;
  constructor(private http: HttpClient, private router: Router) {
    this.getVehicles();
   }

  getVehicles() {
    this.http.post(Urls.getVehicle, {}).subscribe((resp: any) => {
      if (resp.session == true) { // checking whether the session is active or not from response
        var vehicles = JSON.parse(resp.data);
        vehicles.forEach(veh => {
          veh.LastService =  new Date(veh.LastService).toLocaleDateString()
        })
        this.all_vehicles = vehicles;
      }
      else {
        this.router.navigate(['/adminlogin/SessionExpired']);
      }
    })
  }

  ngOnInit() {
  
  }

}
