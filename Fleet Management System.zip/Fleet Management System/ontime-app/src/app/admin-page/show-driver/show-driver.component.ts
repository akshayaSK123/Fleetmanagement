import { Component, OnInit } from '@angular/core';
import 'bootstrap';
import { faCalendar } from '@fortawesome/free-solid-svg-icons'
// import {NgbDate, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import Urls from '../../Urls.js';
import * as $ from 'jquery';


@Component({
  selector: 'app-show-driver',
  templateUrl: './show-driver.component.html',
  styleUrls: ['./show-driver.component.css']
})
export class ShowDriverComponent implements OnInit {
  driver=[];
  headElements_driver = ['DriverID','DriverName', 'Gender','Phone','Email','AddressLine1','AddressLine2','State','City','Zipcode','Leaveavail'];
  constructor(private http: HttpClient, private router: Router) 
  {
    this.http.post(Urls.getDriver,{}).subscribe((resp:any) =>{
    if(resp.session == true){ // checking whether the session is active or not from response
    this.driver=JSON.parse(resp.data);
    }
    else{
      this.router.navigate(['/']);
    }
  })

} 

  ngOnInit() {
    
}}
