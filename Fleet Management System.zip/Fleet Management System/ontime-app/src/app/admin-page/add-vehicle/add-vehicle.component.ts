import { Component, OnInit } from '@angular/core';
import 'bootstrap';
import { faCalendar } from '@fortawesome/free-solid-svg-icons'
import {NgbDate, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import Urls from '../../Urls.js';

@Component({
  selector: 'app-add-vehicle',
  templateUrl: './add-vehicle.component.html',
  styleUrls: ['./add-vehicle.component.css']
})
export class AddVehicleComponent implements OnInit {
  faCalendar = faCalendar;
  seatLayout: any;
  vehicle: any = {};
  response=false;
  earliestBookingDate:any;
  capacity;
  constructor(private calendar: NgbCalendar,
    private http: HttpClient) {
    this.earliestBookingDate = calendar.getToday();
  }

  setLayout(seat) {
    this.seatLayout = seat.Layout;
    this.capacity = seat.capacity;
  }
  addVehicle() {
    this.vehicle.seatLayout = this.seatLayout;
    this.vehicle.r_len = this.seatLayout.length;
    this.vehicle.c_len = this.seatLayout[0].length;
    this.vehicle.seats = this.capacity;
    var lastServiceDate = this.vehicle.lastServiceDate;
    //Deep copy 
    var vehicle = JSON.parse(JSON.stringify(this.vehicle));
    vehicle.lastServiceDate = new Date(lastServiceDate.year, lastServiceDate.month - 1, lastServiceDate.day).toISOString();
    this.http.post(Urls.addVehicle, vehicle).subscribe((resp: any) => {
      if(resp.success = true)
      {

      }
     })
    console.log(vehicle)
this.vehicle={};
this.response=true;
  }


  ngOnInit() {

  }

}
