import { Component, OnInit } from '@angular/core';
import 'bootstrap';
import { faCalendar } from '@fortawesome/free-solid-svg-icons'
// import {NgbDate, NgbCalendar} from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import Urls from '../../Urls.js';
import * as $ from 'jquery';


@Component({
  selector: 'app-show-trip',
  templateUrl: './show-trip.component.html',
  styleUrls: ['./show-trip.component.css']
})
export class ShowTripComponent implements OnInit {
  all_trips=[]  ;
  selected_trip;
  drivers=[];
  selected_Driver;
  headElements_trip=['tripid','origin','destination','departure','arrival','vehicle_id','driver_id','fare','status'];

  constructor(private http: HttpClient, private router: Router) {
    this.getTrip();

   }
   onModalReady(id,driver_id)
   {
     this.selected_trip = id
     this.selected_Driver = driver_id;
     setTimeout(() => {
      $('.selectpicker').selectpicker('refresh');
    }, 100);

   }
   assignDriver(){
    this.http.post(Urls.addSchedule, {"tripid":this.selected_trip,"driverid":this.selected_Driver}).subscribe((resp: any) => {
      if (resp.session == true) { // checking whether the session is active or not from response
        // var trips = JSON.parse(resp.data)
      }
      $('#exampleModalCenter').modal('hide')
      this.getTrip()
      // else{
        // this.router.navigate(['/']);
      // }
      })
        
     
   }
  getTrip() {
    this.http.post(Urls.getTrip, {}).subscribe((resp: any) => {
      if (resp.session == true) { // checking whether the session is active or not from response
        var trips = JSON.parse(resp.data)
        trips.forEach(trp => {
          trp.arrival =  new Date(trp.arrival).toLocaleString('en-US')
          trp.departure =  new Date(trp.departure).toLocaleString('en-US')

        })
        this.http.post(Urls.getDriver,{}).subscribe((resp:any) =>{
          if(resp.session == true){ // checking whether the session is active or not from response
          this.drivers=JSON.parse(resp.data);
          }
          setTimeout(() => {
            $('.selectpicker').selectpicker('refresh');
          }, 500);
        this.all_trips = trips;
        })
      }
      else {
        this.router.navigate(['/']);
      }
    })
  }

  

  ngOnInit() {
    $('.selectpicker').selectpicker();

  }

}
