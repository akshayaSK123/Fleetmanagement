import { Component, OnInit } from '@angular/core';
import * as $ from 'jquery';
import 'bootstrap';
import { faCalendar, faExchangeAlt } from '@fortawesome/free-solid-svg-icons'
import { NgbDate, NgbCalendar } from '@ng-bootstrap/ng-bootstrap';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import Urls from '../../Urls.js';


@Component({
  selector: 'app-add-trip',
  templateUrl: './add-trip.component.html',
  styleUrls: ['./add-trip.component.css']
})
export class AddTripComponent implements OnInit {
  faCalendar = faCalendar;
  faExchangeAlt = faExchangeAlt;
  days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
  trip: any = { "days": {} }
  origins: any = [];
  vehicles: any = [];
  response=false
   faCalender = faCalendar;
  earliestBookingDate: any;
  lastBookingDate: any;
  errorMessage = "";
  validation = true;

  swap() {
    var temp = this.trip.originId ? this.trip.originId : "";
    this.trip.originId = this.trip.destinationId ? this.trip.destinationId : "";
    this.trip.destinationId = temp;
    $('.origin').selectpicker('val', this.trip.originId);
    $('.dest').selectpicker('val', this.trip.destinationId);
  }
  tripTotal(){
    var x =this.trip.VehicleId?parseInt(this.trip.VehicleId.split('/-/')[1]):0;
    var y = this.trip.fare?this.trip.fare:0
    return x * y
 
  }

  constructor(private calendar: NgbCalendar,
    private http: HttpClient,
  ) {
    //getting All Locations for dropdown
    this.http.post(Urls.getLocation, {}).subscribe((resp: any) => {
             var resporigins = JSON.parse(resp.data);
        resporigins.forEach(loc => {
          this.origins.push({ "City_State": loc.Locationcity + "," + loc.Locationstate, "id": loc.LocationID })
        })
    });
    this.http.post(Urls.getVehicle, {}).subscribe((resp: any) => {
      if (resp.session == true) { // checking whether the session is active or not from response
        var vehicles = JSON.parse(resp.data);
        vehicles.forEach(veh => {
          this.vehicles.push({ "id": veh.VehiclePlateno, "seats": veh.seats })
        })
        setTimeout(() => {
          $('.vehicles').selectpicker('refresh');
        }, 500);
      }
    })

    this.earliestBookingDate = calendar.getToday();
    this.lastBookingDate = calendar.getNext(calendar.getToday(), 'd', 60);
  }
  validateDays() {
    var self = this;
    var validation = false;
    var keys = Object.keys(this.trip.days);
    keys.forEach(element => {
      if (self.trip.days[element] == true)
        validation = true;
    });
    return validation;
  }
  addTrip() {
    var startDate = this.trip.startdate;
    var deptime = this.trip.deptime;
    var arrtime = this.trip.arrtime;
    var trip_input = JSON.parse(JSON.stringify(this.trip));
    trip_input.VehicleId = this.trip.VehicleId.split('/-/')[0];
    trip_input.arrdep = [];
    if (this.trip.freq == 2) {
      var enddate = this.calendar.getNext(this.trip.enddate, 'd', 1);
      if (this.trip.days.length != 0 && this.validateDays()) {
        for (var i = 0; i <= 60; i++) {
          var depdate = this.calendar.getNext(this.trip.startdate, 'd', i);

          if (depdate.before(enddate)) {
            var arrdate = this.calendar.getNext(depdate, 'd', this.trip.arrDay ? this.trip.arrDay : 0);

            if (this.trip.days[this.calendar.getWeekday(depdate)] == true) {

              trip_input.arrdep.push({
                "arr": new Date(arrdate.year, arrdate.month - 1, arrdate.day, arrtime.hour, arrtime.minute).toISOString(),
                "dep": new Date(depdate.year, depdate.month - 1, depdate.day, deptime.hour, deptime.minute).toISOString()
              });

            }

          }
          else
            break;
        }
      }
      else {
        this.errorMessage = "Select the recurring days"
        this.validation = false
      }
    }
    else {
      var arrDate = this.calendar.getNext(this.trip.startdate, 'd', this.trip.arrDay ? this.trip.arrDay : 0);
      trip_input.arrdep.push({
        "arr": new Date(arrDate.year, arrDate.month - 1, arrDate.day, arrtime.hour, arrtime.minute).toISOString(),
        "dep": new Date(startDate.year, startDate.month - 1, startDate.day, deptime.hour, deptime.minute).toISOString()
      });
    }
    console.log(trip_input)
    this.http.post(Urls.addTrip,trip_input).subscribe((resp:any) =>{})
    this.trip = { "days": {} };
    this.response=true;



  }
  ngOnInit() {
    $('.selectpicker').selectpicker();
  }

}
