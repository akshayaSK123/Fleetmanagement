import { Component, OnInit } from '@angular/core';
import 'bootstrap';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import Urls from '../../Urls.js';

@Component({
  selector: 'app-add-location',
  templateUrl: './add-location.component.html',
  styleUrls: ['./add-location.component.css']
})


export class AddLocationComponent implements OnInit {
  new_location: any = {};
  // field:String = "LocationId";
  all_locations: any;
  headElements = ['LocationID', 'Locationcity','Locationstate'];
  constructor(private http: HttpClient, private router: Router) { }

  
  addLocation() {
    this.http.post(Urls.addLocation, this.new_location).subscribe((resp: any) => {
      if (resp.error != true) {
        this.getLocation()
        this.new_location={}
      }
    })
  }


  // onfieldchange(field) {
  //   console.log(field)
  //  this.field = field;
  // }
  // search(searchStr)
  // {
  //   this.http.post(Urls.getLocation,{"field":this.field,"value":searchStr}).subscribe((resp:any) =>{
  //     if(resp.session == true){ // checking whether the session is active or not from response
  //       this.all_locations=JSON.parse(resp.data);
  //     }
  //     else{
  //       this.router.navigate(['/']);
  //     }
  //   })
  // }

  getLocation() {
    this.http.post(Urls.getLocation, {}).subscribe((resp: any) => {
        this.all_locations = JSON.parse(resp.data);
    })
    
    
  }

  ngOnInit() {
    this.getLocation();

  }
  
}