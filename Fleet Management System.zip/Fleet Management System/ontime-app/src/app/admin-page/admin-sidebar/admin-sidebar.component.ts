import { Component, OnInit , Output , EventEmitter } from '@angular/core';
import * as $ from 'jquery';
import 'bootstrap';


@Component({
  selector: 'app-admin-sidebar',
  templateUrl: './admin-sidebar.component.html',
  styleUrls: ['./admin-sidebar.component.css']
})
export class AdminSidebarComponent implements OnInit {
  
  //To transfer the value to parent component
  @Output() activeContent = new EventEmitter<Number>()
  activeMenu:Number;

  constructor() { }

  changeContent(id)
  {
    this.activeContent.emit(id);
    this.activeMenu = id   
  }

  ngOnInit() {
    $('.collapse').collapse('hide')
  }

}
