import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import Urls from '../../Urls.js';

@Component({
  selector: 'app-fgt-password',
  templateUrl: './fgt-password.component.html',
  styleUrls: ['./fgt-password.component.css']
})
export class FgtPasswordComponent implements OnInit {
  resetPwd = false;
  resetError = false;
  userId:any={};
  public get router(): Router {
    return this._router;
  }
  public set router(value: Router) {
    this._router = value;
  }
  @Input() mode: any;
  constructor(private http: HttpClient,private _router: Router) { }
  resetPassword() {
    this.http.post(Urls.resetPassword, {"userId":this.userId.userId,"time":new Date().toISOString()}).subscribe((resp: any) => {
      if (resp.data == "Success") { 
       this.resetPwd = true;
      }
      else {
        this.resetError = true;
      }
    })
  }
  ngOnInit() {
  }
  close() {
    this.router.navigate(['']);
  }
  register() {
    this.router.navigate(["/register"]);
  }
  login() {
    this.router.navigate(["/login"]);
  }

}
