import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Adminlogin1Component } from './adminlogin1.component';

describe('Adminlogin1Component', () => {
  let component: Adminlogin1Component;
  let fixture: ComponentFixture<Adminlogin1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Adminlogin1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Adminlogin1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
