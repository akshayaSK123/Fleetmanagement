import { Component, OnInit, Input } from '@angular/core';
import { Router ,ActivatedRoute} from '@angular/router';
import { HttpClient } from '@angular/common/http';
import 'bootstrap';
import Urls from '../../Urls.js';

@Component({
  selector: 'app-adminlogin1',
  templateUrl: './adminlogin1.component.html',
  styleUrls: ['./adminlogin1.component.css']
})
export class Adminlogin1Component implements OnInit {

  userCreds: any = {};
  loginError = false;
  sessionExpired = false;
  public get router(): Router {
    return this._router;
  }
  public set router(value: Router) {
    this._router = value;
  }
  @Input() mode: any;
  constructor(private _router: Router, private http: HttpClient,private route: ActivatedRoute) { }
  authadmin() {
    this.http.post(Urls.adminlogin1, this.userCreds).subscribe((resp: any) => {
      if (resp.session == true) {
        // checking whether the session is active or not from response
        this.router.navigate(['/admin']);
      }
      else {
      this.sessionExpired = false;
        this.loginError = true;
      }
    });
  }
  ngOnInit() {
  
  this.route.params.subscribe(params => {
    if(params['message'] == "SessionExpired" )
    {
      this.sessionExpired= true;
    }
  })
  }
}