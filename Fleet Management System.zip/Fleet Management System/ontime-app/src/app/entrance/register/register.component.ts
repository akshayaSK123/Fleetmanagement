import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import Urls from '../../Urls.js';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  userCreds:any={};
  register=false;
  public get router(): Router {
    return this._router;
  }
  public set router(value: Router) {
    this._router = value;
  }
  @Input() mode: any;
  constructor(private _router: Router,private http: HttpClient) { }

  reg(){
    console.log(this.userCreds)
    this.http.post(Urls.register, this.userCreds).subscribe((resp: any) => {
      if (resp.session == true) { // checking whether the session is active or not from response
        this.router.navigate(['/']);
      }
      else {
        console.log("error")
      }
    })
  }

  ngOnInit() {
  }
  close(){
    this.router.navigate(['']);
  }
  login()
  {
 this.router.navigate(["/login"]);
  }
 
}
