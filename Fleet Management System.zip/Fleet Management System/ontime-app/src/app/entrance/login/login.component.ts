import { Component, OnInit, Input } from '@angular/core';
import { Router, UrlSegment } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import * as $ from 'jquery';
import 'bootstrap';
import Urls from '../../Urls.js';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
 userCreds:any={};
  login=false;
  public get router(): Router {
    return this._router;
  }
  public set router(value: Router) {
    this._router = value;
  }
  @Input() mode: any;
  constructor(private _router: Router,private http: HttpClient) { }
auth(){
  console.log(this.userCreds)
  this.http.post(Urls.login, this.userCreds).subscribe((resp: any) => {
    if (resp.session == true) { // checking whether the session is active or not from response
      this.router.navigate(['/'],{state:{"userid":this.userCreds.userid}});
    }
    else {
      console.log("error")
    }
  })
}
  ngOnInit() {
  }

  close(){
    this.router.navigate(['']);
  }

  register()
  {
 this.router.navigate(["/register"]);
  }
  fgtpassword()
  {
 this.router.navigate(["/fgt-password"]);
  }
  
 
}
    
          