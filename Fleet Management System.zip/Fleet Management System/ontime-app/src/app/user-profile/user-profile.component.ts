import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import Urls from '../Urls.js';
import 'bootstrap';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {
  user: any ={} ;
session = false;
  constructor(private http: HttpClient, private router: Router) { };

  getUserProfile() {
    
    this.http.post(Urls.getUserProfile, {"username":localStorage.getItem("userId")}).subscribe((resp: any) => {
      if (resp.session == true) { // checking whether the session is active or not from response
        this.user = JSON.parse(resp.data)[0];
        this.user.email = localStorage.getItem("userId");
      }
      else {
        this.router.navigate(['/']);
      }
    })
    }
  
    updUserProfile() {
      this.user.userid = localStorage.getItem("userId");
      this.http.post(Urls.updUserProfile, this.user).subscribe((resp: any) => {
        if (resp.session == true) { // checking whether the session is active or not from response
        }
        else {
          this.router.navigate(['/']);
        }
      })
    }
  
  ngOnInit() {
    var userId = window.history.state.userid ?window.history.state.userid: localStorage.getItem('userId');
    this.session = userId !="null" && userId !=""  ? true:false;
    this.getUserProfile()
 
  }

}
