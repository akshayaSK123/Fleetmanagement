import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import Urls from '../Urls.js';
import { faSearchDollar } from '../../../node_modules/@fortawesome/free-solid-svg-icons';


@Component({
  selector: 'app-reset-pass',
  templateUrl: './reset-pass.component.html',
  styleUrls: ['./reset-pass.component.css']
})
export class ResetPassComponent implements OnInit {
ValidToken=false;
resetDone=false;
token;
errorMessage="";
passwordMatch;
pwd:any={};

constructor(private http: HttpClient,private route: ActivatedRoute) { }
updatePassword()
{
  if(this.pwd.password)
  this.http.post(Urls.updPassword, {"tokenid":this.token,"password":this.pwd.password}).subscribe((resp: any) => {
    if (resp.data.toLowerCase() == "success") { // checking whether the session is active or not from response
     this.resetDone = true ;
    }
    else
    {this.errorMessage="Password Reset Failed. Try using a different password"}
  })
  else
  this.passwordMatch=true
}
resetMatch(){
  this.errorMessage = "";
  if( (this.pwd.password  || this.pwd.confirmpassword ) && this.pwd.password != this.pwd.confirm_password)
  this.passwordMatch= true 
 else
 this.passwordMatch= false 
 
}
  ngOnInit() {
    this.route.params.subscribe(params => {
    this.token = params['token'];
      this.http.post(Urls.isTokenValid, {"token":this.token}).subscribe((resp: any) => {
        if (resp.data == "Success") { // checking whether the session is active or not from response
         this.ValidToken = true;
        }
    })

  })
  }
}
