import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FirstPageComponent} from './first-page/first-page.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { LoginComponent } from './entrance/login/login.component';
import { RegisterComponent } from './entrance/register/register.component';
import { FgtPasswordComponent } from './entrance/fgt-password/fgt-password.component';
import { SearchResultsComponent } from './first-page/search-results/search-results.component';
import { ShowBookingComponent } from './first-page/show-booking/show-booking.component';
import { ResetPassComponent } from './reset-pass/reset-pass.component';
import { BookingconfirmedComponent } from './first-page/bookingconfirmed/bookingconfirmed.component';
import { AboutusComponent } from './first-page/aboutus/aboutus.component';
import { Adminlogin1Component } from './entrance/adminlogin1/adminlogin1.component';
import { ContactusComponent } from './first-page/contactus/contactus.component';
import { SchedulesComponent } from './first-page/schedules/schedules.component';

//https://stackoverflow.com/questions/37693411/cannot-match-any-routes
const routes: Routes = [
 { path: '', component: FirstPageComponent , pathMatch:'full'},
 { path: 'myProfile', component: UserProfileComponent ,pathMatch:'full'},
 { path: 'UserRegistration', component: UserRegistrationComponent ,pathMatch:'full'},
 { path: 'admin', component: AdminPageComponent ,pathMatch:'full'},
 { path: 'login', component: LoginComponent ,pathMatch:'full'},
 { path: 'register', component: RegisterComponent ,pathMatch:'full'},
 { path: 'forgot', component: FgtPasswordComponent ,pathMatch:'full'},
 { path: 'admin', component: AdminPageComponent ,pathMatch:'full'},
 { path:'plan/:originId/:destinationId/:onward/:return' , component:SearchResultsComponent,pathMatch:'full'},
 { path:'mybooking' , component:ShowBookingComponent,pathMatch:'full'},
 { path:'reset/:token' , component:ResetPassComponent,pathMatch:'full'}, 
 { path:'aboutus' , component:AboutusComponent,pathMatch:'full'},
 { path:'adminlogin/:message' , component:Adminlogin1Component,pathMatch:'full'},
 { path:'contactus' , component:ContactusComponent,pathMatch:'full'},
 { path:'bookingConfirmation/:bookingId' , component:BookingconfirmedComponent,pathMatch:'full'},
 {path: 'adminlogin', redirectTo: 'adminlogin/'},
 { path:'schedules' , component:SchedulesComponent, pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
