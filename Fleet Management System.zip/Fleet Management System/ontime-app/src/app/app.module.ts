import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome'
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FirstPageComponent } from './first-page/first-page.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { SearchComponent } from './first-page/search/search.component';
import { AdminPageComponent } from './admin-page/admin-page.component';
import { BusLayoutComponent } from './others/bus-layout/bus-layout.component';
import { AddTripComponent } from './admin-page/add-trip/add-trip.component';
import { HeaderComponent } from './first-page/header/header.component';
import { AdminSidebarComponent } from './admin-page/admin-sidebar/admin-sidebar.component';
import { AdminContentComponent } from './admin-page/admin-content/admin-content.component';
import { AddDriverComponent } from './admin-page/add-driver/add-driver.component';
import { AddVehicleComponent } from './admin-page/add-vehicle/add-vehicle.component';
import { AddLocationComponent } from './admin-page/add-location/add-location.component';
import { LoginComponent } from './entrance/login/login.component';
import { RegisterComponent } from './entrance/register/register.component';
import { FgtPasswordComponent } from './entrance/fgt-password/fgt-password.component';
import { FooterComponent } from './first-page/footer/footer.component';
import { ShowDriverComponent } from './admin-page/show-driver/show-driver.component';
import { SearchResultsComponent } from './first-page/search-results/search-results.component';
import { ViewVehiclesComponent } from './admin-page/view-vehicles/view-vehicles.component';
import { ShowTripComponent } from './admin-page/show-trip/show-trip.component';
import { ShowBookingComponent } from './first-page/show-booking/show-booking.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
  
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AboutusComponent } from './first-page/aboutus/aboutus.component';
import { ResetPassComponent } from './reset-pass/reset-pass.component';
import { Adminlogin1Component } from './entrance/adminlogin1/adminlogin1.component';
import { BookingconfirmedComponent } from './first-page/bookingconfirmed/bookingconfirmed.component';
import { ContactusComponent } from './first-page/contactus/contactus.component';
import { ChristmasComponent } from './first-page/aboutus/christmas/christmas.component';
import { SchedulesComponent } from './first-page/schedules/schedules.component';

@NgModule({
  declarations: [
    AppComponent,
    FirstPageComponent,
    UserProfileComponent,
    UserRegistrationComponent,
    SearchComponent,
    AdminPageComponent,
    BusLayoutComponent,
    AddTripComponent,
    HeaderComponent,
    AdminSidebarComponent,
    AdminContentComponent,
    AddDriverComponent,
    AddVehicleComponent,
    AddLocationComponent,
    LoginComponent,
    RegisterComponent,
    FgtPasswordComponent,
    FooterComponent,
    ShowDriverComponent,
    SearchResultsComponent,
    ViewVehiclesComponent,
    ShowTripComponent,
    ShowBookingComponent,
    AboutusComponent,
    ResetPassComponent,
    Adminlogin1Component,
    BookingconfirmedComponent,
    ContactusComponent,
    ChristmasComponent,
    SchedulesComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    FontAwesomeModule,
    NgbModule,
    MDBBootstrapModule.forRoot()
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
