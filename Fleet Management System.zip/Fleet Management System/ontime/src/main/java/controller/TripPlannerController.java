package controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import helper.HelperFunctions;
import models.Response;

@RestController
public class TripPlannerController {
	@PostMapping("/search")
	public Response search(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		// Check for auth Cookie to logout after 30 mins inactivity
		try {
				JSONObject Obj = new JSONObject(params);

				resp = TripPlanner.searchTrip(Obj);
				resp.session = true;
				// adding cookie to response to extend the session for next 30
				// mins
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // parsing the request body to JSON

		return resp;

	}
	
	// API- to get all booking details for a user
		@PostMapping("/getBookings")
		public Response getBookings(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

			Response resp = new Response();
			resp.error = false;
			resp.session = true;
			Cookie[] cookies = request.getCookies();
			// Check for auth Cookie to logout after 30 mins inactivity
			try {
				if (cookies != null && HelperFunctions.checkAuthCookie(cookies)) {
				JSONObject Obj = new JSONObject(params); // parsing the request body
															// to JSON
				resp = TripPlanner.getBookings(Obj);
				resp.session = true;
				// adding cookie to response to extend the session for next 30 mins
				Cookie cookie = new Cookie("auth", "true");
				cookie.setMaxAge(1800);
				response.addCookie(cookie);
				 } else {
				// If auth cookie is not there, sending the session in response to
				// false.
				 resp.session = false;
				 }

			} catch (Exception e) {
				e.printStackTrace();
				resp.error = true;
			}
			return resp;
		}


}
