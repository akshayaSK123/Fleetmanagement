package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.json.JSONObject;

import helper.HelperFunctions;
import models.Response;

public class UserFunctions {
	public static Response Login(JSONObject Obj) {

		Response resp = new Response(); // creating a response obj to be sent
										// back
		try {
			resp.error = false;
			resp.session = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.getAUTH());
			pstmt.setString(1, Obj.getString("userid"));
			pstmt.setString(2, Obj.getString("password"));
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) { 
				if (rs.getInt(1) == 1) {
					resp.session = true;
					resp.data = "Login successful";
				} else
					resp.data = "Login failed";

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;
			// System.out.println(e);

		}
		return resp;
	}

	public static Response adminlogin(JSONObject Obj) {

		Response resp = new Response(); // creating a response obj to be sent
										// back
		try {
			resp.error = false;
			resp.session = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.adminlogin());
			pstmt.setString(1, Obj.getString("username"));
			pstmt.setString(2, Obj.getString("password"));
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				if (rs.getInt(1) == 1)
					resp.session = true;

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;
			// System.out.println(e);

		}
		return resp;
	}

	public static Response resetPassword(JSONObject Obj) {

		Response resp = new Response(); // creating a response obj to be sent
										// back
		try {
			resp.error = false;
			resp.session = false;
			resp.data="Failed";
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.validUser());
			pstmt.setString(1, Obj.getString("userId"));
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) { // looping the results
				if (rs.getInt(1) == 1) {
					Boolean update = true;
					while (update) {
						String Link = java.util.UUID.randomUUID().toString();
						PreparedStatement pstmt_Update = conn.prepareStatement(DbQuery.getresetPass());
						pstmt_Update.setString(1, Obj.getString("userId"));
						pstmt_Update.setString(2, Link);
						pstmt_Update.setString(3, Obj.getString("time"));
						int reset = pstmt_Update.executeUpdate();
						if (reset == 1) {
							 HelperFunctions.SendResetMail(Obj.getString("userId"),Link);
							 resp.data="Success";
							update = false;
						}
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;
			// System.out.println(e);

		}
		return resp;
	}

	public static Response checkToken(JSONObject Obj) {

		Response resp = new Response(); // creating a response obj to be sent
										// back
		try {
			resp.error = false;
			resp.session = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.checkToken());
			pstmt.setString(1, Obj.getString("token"));
			int rs = pstmt.executeUpdate();
			if (rs == 1) {
				resp.data = "Success";
			
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;
			// System.out.println(e);

		}
		return resp;
	}
	
	//register new user to database
	public static Response register(JSONObject Obj) {

		Response resp = new Response(); // creating a response obj to be sent
										// back
		try {
			resp.error = false;
			resp.session = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.register());
			pstmt.setString(1, Obj.getString("userid"));
			pstmt.setString(2, Obj.getString("password"));
			int status = pstmt.executeUpdate();

			if (status == 1) {
				resp.data = "Success";
			} else
				resp.data = "Failed";

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;
			// System.out.println(e);

		}
		return resp;
	}
}
