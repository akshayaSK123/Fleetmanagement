package controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import helper.HelperFunctions;
import models.Response;

@CrossOrigin
@RestController
public class UserController {

	@GetMapping("/Test")
	public String Test(HttpServletResponse response) {
		return "Working Fine";

	}

	// API- to get all driver details
	@PostMapping("/getDriver")
	public Response getDriver(HttpServletRequest request, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		// Check for auth Cookie to logout after 30 mins inactivity
		 if (cookies != null && HelperFunctions.checkAdminCookie(cookies)) {

		resp = Adminfunctions.getDriver();
		resp.session = true;
		// adding cookie to response to extend the session for next 30 mins
		Cookie cookie = new Cookie("adminSession", "true");
		cookie.setMaxAge(1800);
		response.addCookie(cookie);
		 } else {
		// If auth cookie is not there, sending the session in response to
		// false.
		 resp.session = false;
		 }
		return resp;

	}

	
	// API- to get all vehicle details
	@PostMapping("/getVehicle")
	public Response getVehicle(HttpServletRequest request, HttpServletResponse response) {
		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		// Check for auth Cookie to logout after 30 mins inactivity
		 if (cookies != null && HelperFunctions.checkAuthCookie(cookies)) {
		resp = Adminfunctions.getVehicle();
		resp.session = true;
		// adding cookie to response to extend the session for next 30 mins
		Cookie cookie = new Cookie("adminSession", "true");
		cookie.setMaxAge(1800);
		response.addCookie(cookie);
		 } else {
		// If auth cookie is not there, sending the session in response to
		// false.
		 resp.session = false;
		 }
		return resp;

	}

	// API- to get all location details
	@PostMapping("/getLocation")
	public Response getLocation(HttpServletRequest request, HttpServletResponse response) {
		Response resp = new Response();
		resp.error = false;
		resp.session = false;
		resp = Adminfunctions.getLocation();
		return resp;
		//As the API is common to all both admin and users , cookie time is not extended

	}

	// API- to insert into driver
	@PostMapping("/addDriver")
	public Response AddDriver(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		// Check for auth Cookie to logout after 30 mins inactivity
		try {
			 if (cookies != null && HelperFunctions.checkAdminCookie(cookies)) {
			JSONObject Obj = new JSONObject(params); // parsing the request body
														// to JSON
			resp = Adminfunctions.addDriver(Obj);
			resp.session = true;
			// adding cookie to response to extend the session for next 30 mins
			Cookie cookie = new Cookie("adminSession", "true");
			cookie.setMaxAge(1800);
			response.addCookie(cookie);
			 } else {
			// If auth cookie is not there, sending the session in response to
			// false.
			 resp.session = false;
			 }

		} catch (Exception e) {
			e.printStackTrace();
			resp.error = true;
		}
		return resp;
	}

	// API- for user login
	@PostMapping("/login")
	public Response Login(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		try {
			JSONObject Obj = new JSONObject(params); // parsing the request body
														// to JSON
			resp = UserFunctions.Login(Obj);
			if (resp.session == true) {
				// adding cookie to response to extend the session for next 30
				// mins
				Cookie cookie = new Cookie("auth", "true");
				cookie.setMaxAge(1800);
				response.addCookie(cookie);
			} else {
				// If auth cookie is not there, sending the session in response
				// to false.
				resp.session = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			resp.error = true;
		}
		return resp;
	}

	//API- for user signout
	@PostMapping("/signout")
	public Response uploadData2(HttpServletResponse Response) {
		Response resp = new Response();
		resp.error = false;
		resp.data = "";
		resp.session = false;
		Cookie cookie = new Cookie("auth", "");
		cookie.setMaxAge(0); // clearing the cookie in the browser by setting the time to 0
		Response.addCookie(cookie);
		return resp;

	}
	
	//API- for admin signout
	@PostMapping("/adminsignout")
	public Response uploadData3(HttpServletResponse Response) {
		Response resp = new Response();
		resp.error = false;
		resp.data = "";
		resp.session = false;
		Cookie cookie = new Cookie("adminSession", "");
		cookie.setMaxAge(0); // clearing the cookie in the browser by setting the time to 0
		Response.addCookie(cookie);
		return resp;

	}
	
	
	//API- for admin login
		@PostMapping("/adminlogin1")
		public Response adminlogin( @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		try {
			JSONObject Obj = new JSONObject(params); // parsing the request body
														// to JSON
			resp = UserFunctions.adminlogin(Obj);
			if (resp.session == true) {
				// adding cookie to response to extend the session for next 30
				// mins
				Cookie cookie = new Cookie("adminSession", "true");
				cookie.setMaxAge(1800);
				response.addCookie(cookie);
			} else {
				// If auth cookie is not there, sending the session in response
				// to false.
				resp.session = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
			resp.error = true;
		}
		return resp;
	}

	// API- for user registration
	@PostMapping("/register")
	public Response register(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = false;
		try {
			JSONObject Obj = new JSONObject(params); // parsing the request body
														// to JSON
			resp = UserFunctions.register(Obj);
			
		} catch (Exception e) {
			e.printStackTrace();
			resp.error = true;
		}
		return resp;
	}

	// API- to insert into bookings
	@PostMapping("/addBooking")
	public Response AddBooking(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		try {
			// Check for auth Cookie to logout after 30 mins inactivity
			 if (cookies != null && HelperFunctions.checkAuthCookie(cookies)) {
			JSONObject Obj = new JSONObject(params); // parsing the request body
														// to JSON
			resp = Adminfunctions.addBooking(Obj);
			resp.session = true;
			// adding cookie to response to extend the session for next 30 mins
			Cookie cookie = new Cookie("auth", "true");
			cookie.setMaxAge(1800);
			response.addCookie(cookie);
			 } else {
			// If auth cookie is not there, sending the session in response to
			// false.
			 resp.session = false;
			 }

		} catch (Exception e) {
			e.printStackTrace();
			resp.error = true;
		}
		return resp;
	}

	// API- to insert into location
	@PostMapping("/addLocation")
	public Response AddLocation(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		// Check for auth Cookie to logout after 30 mins inactivity
		// if (cookies != null && HelperFunctions.checkAuthCookie(cookies)) {
		try {
			JSONObject Obj = new JSONObject(params); // parsing the request body
														// to JSON
			resp = Adminfunctions.addLocation(Obj);
			resp.session = true;
			// adding cookie to response to extend the session for next 30 mins
			Cookie cookie = new Cookie("adminSession", "true");
			cookie.setMaxAge(1800);
			response.addCookie(cookie);
			// } else {
			// If auth cookie is not there, sending the session in response to
			// false.
			// resp.session = false;
			// }

		} catch (Exception e) {
			e.printStackTrace();
			resp.error = true;
		}
		return resp;
	}

	// API- to insert into schedule
	@PostMapping("/addSchedule")
	public Response AddSchedule(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		// Check for auth Cookie to logout after 30 mins inactivity
		// if (cookies != null && HelperFunctions.checkAuthCookie(cookies)) {
		try {
			JSONObject Obj = new JSONObject(params); // parsing the request body
														// to JSON
			 resp = Adminfunctions.addSchedule(Obj);
			// resp.session = true;
			// adding cookie to response to extend the session for next 30 mins
			Cookie cookie = new Cookie("auth", "true");
			cookie.setMaxAge(1800);
			response.addCookie(cookie);
			// } else {
			// If auth cookie is not there, sending the session in response to
			// false.
			// resp.session = false;
			// }

		} catch (Exception e) {
			e.printStackTrace();
			resp.error = true;
		}
		return resp;
	}

	// API- to get all location details
	@PostMapping("/getTrip")
	public Response GetTrip(HttpServletRequest request, HttpServletResponse response) {
		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		// Check for auth Cookie to logout after 30 mins inactivity
		// if (cookies != null && HelperFunctions.checkAuthCookie(cookies)) {
		resp = Adminfunctions.getTrip();
		resp.session = true;
		// adding cookie to response to extend the session for next 30 mins
		Cookie cookie = new Cookie("auth", "true");
		cookie.setMaxAge(1800);
		response.addCookie(cookie);
		// } else {
		// If auth cookie is not there, sending the session in response to
		// false.
		// resp.session = false;
		// }
		return resp;

	}

	@PostMapping("/resetPassword")
	public Response resetPassword(HttpServletRequest request, @RequestBody String params,
			HttpServletResponse response) {
		Response resp = new Response();
		try {
			JSONObject Obj = new JSONObject(params);
			resp.error = false;
			resp.session = false;
			resp = UserFunctions.resetPassword(Obj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resp;

	}

	@PostMapping("/updPassword")
	public Response updPassword(HttpServletRequest request, 
			@RequestBody String params,
			HttpServletResponse response) {
		Response resp = new Response();
		try{
		JSONObject Obj = new JSONObject(params);
		resp.error = false;
		resp.session = false;		
		resp = Adminfunctions.updpswd(Obj);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return resp;

	}

	
	
@PostMapping("/isAdminSession")
	public Response isAdminValid(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		Response resp = new Response();
		if (cookies != null && HelperFunctions.checkAdminCookie(cookies)) {
			resp.session = true;
			// adding cookie to response to extend the session for next 30 mins
			Cookie cookie = new Cookie("adminSession", "true");
			cookie.setMaxAge(1800);
			response.addCookie(cookie);
		} else {
			// If auth cookie is not there, sending the session in response to
			// false.
			resp.session = false;
		}
		return resp;

	}

	@PostMapping("/isTokenValid")
	public Response isTokenValid(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {
		Response resp = new Response();
		try {
			JSONObject Obj = new JSONObject(params);
			resp.error = false;
			resp.session = false;
			resp = UserFunctions.checkToken(Obj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resp;

	}

	@PostMapping("/changePassword")
	public Response changePassword(HttpServletRequest request, @RequestBody String params,
			HttpServletResponse response) {
		Response resp = new Response();
		try {
			JSONObject Obj = new JSONObject(params);
			resp.error = false;
			resp.session = false;
			resp = UserFunctions.resetPassword(Obj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resp;

	}

	// API- to insert into Vehicle
	@PostMapping("/addVehicle")
	public Response AddVehicle(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		// Check for auth Cookie to logout after 30 mins inactivity
		// if (cookies != null && HelperFunctions.checkAuthCookie(cookies)) {
		try {
			JSONObject Obj = new JSONObject(params); // parsing the request body
														// to JSON
			resp = Adminfunctions.addVehicle(Obj);
			resp.session = true;
			// adding cookie to response to extend the session for next 30 mins
			Cookie cookie = new Cookie("auth", "true");
			cookie.setMaxAge(1800);
			response.addCookie(cookie);
			// } else {
			// If auth cookie is not there, sending the session in response to
			// false.
			// resp.session = false;
			// }

		} catch (Exception e) {
			e.printStackTrace();
			resp.error = true;
		}
		return resp;
	}

	@PostMapping("/addTrip")
	public Response AddTrip(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		// Check for auth Cookie to logout after 30 mins inactivity
		// if (cookies != null && HelperFunctions.checkAuthCookie(cookies)) {
		try {
			JSONObject Obj = new JSONObject(params); // parsing the request body
														// to JSON
			resp = Adminfunctions.addTrips(Obj);
			resp.session = true;
			// adding cookie to response to extend the session for next 30 mins
			Cookie cookie = new Cookie("auth", "true");
			cookie.setMaxAge(1800);
			response.addCookie(cookie);
			// } else {
			// If auth cookie is not there, sending the session in response to
			// false.
			// resp.session = false;
			// }

		} catch (Exception e) {
			e.printStackTrace();
			resp.error = true;
		}
		return resp;
	}

	// API- to update vehicle
	@PostMapping("/updVehicle")
	public Response updVehicle(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		// Check for auth Cookie to logout after 30 mins inactivity
		// if (cookies != null && HelperFunctions.checkAuthCookie(cookies)) {
		try {
			JSONObject Obj = new JSONObject(params); // parsing the request body
														// to JSON
			resp = Adminfunctions.updVehicle(Obj);
			resp.session = true;
			// adding cookie to response to extend the session for next 30 mins
			Cookie cookie = new Cookie("auth", "true");
			cookie.setMaxAge(1800);
			response.addCookie(cookie);
			// } else {
			// If auth cookie is not there, sending the session in response to
			// false.
			// resp.session = false;
			// }

		} catch (Exception e) {
			e.printStackTrace();
			resp.error = true;
		}
		return resp;
	}

	// API- to update users
	@PostMapping("/updUser")
	public Response updUsers(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		// Check for auth Cookie to logout after 30 mins inactivity
		// if (cookies != null && HelperFunctions.checkAuthCookie(cookies)) {
		try {
			JSONObject Obj = new JSONObject(params); // parsing the request body
														// to JSON
			resp = Adminfunctions.updateUser(Obj);
			resp.session = true;
			// adding cookie to response to extend the session for next 30 mins
			Cookie cookie = new Cookie("auth", "true");
			cookie.setMaxAge(1800);
			response.addCookie(cookie);
			// } else {
			// If auth cookie is not there, sending the session in response to
			// false.
			// resp.session = false;
			// }

		} catch (Exception e) {
			e.printStackTrace();
			resp.error = true;
		}
		return resp;
	}
	// API- to get users
	@PostMapping("/getUser")
	public Response getUser(HttpServletRequest request, @RequestBody String params, HttpServletResponse response) {

		Response resp = new Response();
		resp.error = false;
		resp.session = true;
		Cookie[] cookies = request.getCookies();
		// Check for auth Cookie to logout after 30 mins inactivity
		// if (cookies != null && HelperFunctions.checkAuthCookie(cookies)) {
		try {
			JSONObject Obj = new JSONObject(params); // parsing the request body
														// to JSON
			resp = Adminfunctions.getUser(Obj);
			resp.session = true;
			// adding cookie to response to extend the session for next 30 mins
			Cookie cookie = new Cookie("auth", "true");
			cookie.setMaxAge(1800);
			response.addCookie(cookie);
			// } else {
			// If auth cookie is not there, sending the session in response to
			// false.
			// resp.session = false;
			// }

		} catch (Exception e) {
			e.printStackTrace();
			resp.error = true;
		}
		return resp;
	}

}
