package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONObject;

import models.Response;

public class TripPlanner {

	public static Response searchTrip(JSONObject Obj) {
		JSONArray jsonArray = new JSONArray();
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();

			PreparedStatement pstmt_data = conn.prepareStatement(DbQuery.searchTrip());
			// pstmt.setString(1, Obj.getString("originId"));
			// pstmt.setString(2, Obj.getString("destinationId"));
			//
			// ResultSet rs = pstmt.executeQuery();

			PreparedStatement pstmt = conn.prepareStatement(DbQuery.searchTrip());
			pstmt.setString(1, Obj.getString("originId"));
			pstmt.setString(2, Obj.getString("destinationId"));
			pstmt.setString(3, Obj.getString("start"));
			pstmt.setString(4, Obj.getString("end"));

			ResultSet rs = pstmt.executeQuery();

			int i = 0; // index to add in JSONArray
			while (rs.next()) { // looping the results

				JSONObject trip = new JSONObject(); // creating a JSON for
													// each driver
				trip.put("TripId", rs.getInt(1));
				trip.put("Dep", rs.getString(4));
				trip.put("Arr", rs.getString(5));
				trip.put("Fare", rs.getInt(7));
				JSONObject rawLayout = TripPlanner.viewSeats(rs.getString(6));
				JSONArray seatLayout = new JSONArray();
				 ArrayList<String> BookedSeats = TripPlanner.getBookedSeats(rs.getInt(1));
				for (int r = 0; r < rs.getInt(14); r++) {
					JSONArray rowEntry = new JSONArray();
					for (int c = 0; c < rs.getInt(15); c++) {
						try {
							//checking if the seatid is in the layout from DB 
							JSONObject seat = rawLayout.getJSONObject(r + "").getJSONObject((c + 1) + "");
							//If yes, checking whether it is booked or not. 
							if(BookedSeats.contains(seat.getString("id_seat")))
								 seat.put("type", "booked");
							 else
								 seat.put("type", "vacant");
							rowEntry.put(c, seat);

						} catch (Exception e) {
							//If the seat id is no there, creating a dummy to render in the UI
							JSONObject seat = new JSONObject();
							seat.put("type", "noseat");
							seat.put("id", new JSONObject().put("r", r).put("c", c + 1));
							rowEntry.put(c, seat);
						}
						seatLayout.put(r, rowEntry);
					}

				}
				trip.put("seats", seatLayout);
				jsonArray.put(i, trip);// Adding the driver to JSONArray
				i++;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;
			// System.out.println(e);

		}
		resp.data = jsonArray.toString();
		return resp;

	}

	public static JSONObject viewSeats(String VehicleId) {

		JSONObject Obj = new JSONObject();
		try {
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();

			PreparedStatement pstmt = conn.prepareStatement(DbQuery.getViewSeats());
			pstmt.setString(1, VehicleId);
			ResultSet rs = pstmt.executeQuery();

			int i = 0; // index to add in JSONArray
			while (rs.next()) { // looping the results

				try {
					Obj.getJSONObject(rs.getInt(2) + "");
				} catch (Exception e) {
					Obj.put(rs.getInt(2) + "", new JSONObject());
				}

				JSONObject seat = new JSONObject(); // creating a JSON for
													// each driver
				seat.put("id_seat", rs.getString(1));
				seat.put("id", new JSONObject().put("r", rs.getInt(2)).put("c", rs.getInt(3)));
				seat.put("seatno", rs.getString(4));
				Obj.getJSONObject(rs.getInt(2) + "").put(rs.getString(3) + "", seat);

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return Obj;

	}
// Function to get list of booked seats in a trip
	public static ArrayList<String> getBookedSeats(int TripID) {

		ArrayList<String> BookedSeats = new ArrayList();
		try {
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();

			PreparedStatement pstmt = conn.prepareStatement(DbQuery.getBookedSeats());
			pstmt.setInt(1, TripID);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) { // looping the results
				BookedSeats.add(rs.getString(1));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return BookedSeats;

	}
	//Function to get all the bookings for a user if booking id is not sent as input 
	public static Response getBookings(JSONObject Obj) {
		JSONArray jsonArray = new JSONArray();
		JSONObject bookings = new JSONObject();
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			String Query = DbQuery.getBookings()+ (Obj.has("bookingId")?"AND B.BookingID = ?":"");
			PreparedStatement pstmt = conn.prepareStatement(Query);
			pstmt.setString(1, Obj.getString("userid"));
			if(Obj.has("bookingId"))
				pstmt.setString(2, Obj.getString("bookingId"));
			
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) { // looping the results
				try {
					bookings.getJSONObject(rs.getString(1)).getJSONArray("seats").put(rs.getString(2));
					int amt = bookings.getJSONObject(rs.getString(1)).getInt("Amount");
					bookings.getJSONObject(rs.getString(1)).put("Amount", amt+rs.getInt(7));
				} catch (Exception e) {
					JSONObject booking = new JSONObject(); // creating a JSON
															// for
					// each booking
					booking.put("bookingid", rs.getString(1));
					booking.put("seats", new JSONArray().put(rs.getInt(2)));
					booking.put("dep", rs.getString(3));
					booking.put("arr", rs.getString(4));
					booking.put("Origin", rs.getString(5));
					booking.put("Dest", rs.getString(6));
					booking.put("Amount", rs.getInt(7));
					bookings.put(rs.getString(1), booking);
				}

			}
			Iterator<String> keys = bookings.keys();

			while (keys.hasNext()) {
				String key = keys.next();

				jsonArray.put(bookings.getJSONObject(key));// Adding the booking
															// to JSONArray
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}
		resp.data = jsonArray.toString();
		return resp;
	}

}
