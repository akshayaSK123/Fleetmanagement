package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.json.JSONArray;
import org.json.JSONObject;

import models.Response;

public class Adminfunctions {

	public static Response getDriver() {
		JSONArray jsonArray = new JSONArray();
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(DbQuery.getalldrivers());
			int i = 0; // index to add in JSONArray
			while (rs.next()) { // looping the results

				JSONObject driver = new JSONObject(); // creating a JSON for
														// each driver
				driver.put("DriverID", rs.getString(1));
				driver.put("DriverName", rs.getString(2));
				driver.put("Gender", rs.getString(3));
				driver.put("Phone", rs.getString(4));
				driver.put("Email", rs.getString(5));
				driver.put("AddressLine1", rs.getString(6));
				driver.put("AddressLine2", rs.getString(7));
				driver.put("State", rs.getString(8));
				driver.put("City", rs.getString(9));
				driver.put("Zipcode", rs.getString(10));
				driver.put("Leaveavail", rs.getString(11));
				jsonArray.put(i, driver);// Adding the driver to JSONArray
				i++;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;
			// System.out.println(e);

		}
		resp.data = jsonArray.toString();
		return resp;

	}

	public static Response getVehicle() {
		JSONArray jsonArray = new JSONArray();
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(DbQuery.getallVehicles());
			int i = 0; // index to add in JSONArray
			while (rs.next()) { // looping the results

				JSONObject vehicle = new JSONObject(); // creating a JSON for
														// each vehicle
				vehicle.put("VehicleModel", rs.getString(1));
				vehicle.put("VehiclePlateno", rs.getString(2));
				vehicle.put("MilesDriven", rs.getInt(3));
				vehicle.put("LastService", rs.getString(4));
				vehicle.put("seats", rs.getInt(5));
				JSONObject rawLayout = TripPlanner.viewSeats(rs.getString(2));
				JSONArray seatLayout = new JSONArray();

				for (int r = 0; r < rs.getInt(6); r++) {
					JSONArray rowEntry = new JSONArray();
					for (int c = 0; c < rs.getInt(7); c++) {
						try {
							rawLayout.getJSONObject(r + "").getJSONObject((c + 1) + "").put("type", "view");
							rowEntry.put(c, rawLayout.getJSONObject(r + "").getJSONObject((c + 1) + ""));

						} catch (Exception e) {
							JSONObject seat = new JSONObject();
							seat.put("type", "noseat");
							seat.put("id", new JSONObject().put("r", r).put("c", c + 1));
							rowEntry.put(c, seat);
						}
						seatLayout.put(r, rowEntry);
					}

				}

				vehicle.put("seatLayout", seatLayout);

				jsonArray.put(i, vehicle);// Adding the vehicle to JSONArray
				i++;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}
		resp.data = jsonArray.toString();
		return resp;
	}

	public static Response getTrip() {
		JSONArray jsonArray = new JSONArray();
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(DbQuery.getallTrips());
			int i = 0; // index to add in JSONArray
			while (rs.next()) { // looping the results

				JSONObject trips = new JSONObject(); // creating a JSON for
														// each vehicle
				trips.put("tripid", rs.getInt(1));
				trips.put("origin", rs.getInt(2));
				trips.put("destination", rs.getInt(3));
				trips.put("departure", rs.getString(4));
				trips.put("arrival", rs.getString(5));
				trips.put("vehicleid", rs.getString(6));
				trips.put("fare", rs.getInt(7));
				trips.put("status", rs.getString(8));
				trips.put("driver_id", rs.getString(9) != null ? rs.getString(9) : "assign");
				trips.put("driver_name", rs.getString(12) != null ? rs.getString(12) : "assign");
				jsonArray.put(i, trips);// Adding the vehicle to JSONArray
				i++;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}
		resp.data = jsonArray.toString();
		return resp;
	}

	
	
//This is used to update the user table for edit profile
	public static Response updateUser(JSONObject Obj) {

		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.updUsers());
			
			pstmt.setString(1,Obj.has("username")? Obj.getString("username"):"");
		    pstmt.setString(2, Obj.has("gender") ? Obj.getString("gender"):"");
		    pstmt.setString(3, Obj.has("phone") ? Obj.getString("phone"):"");
		    pstmt.setString(4, Obj.has("addressline1") ? Obj.getString("addressline1"):"");
		    pstmt.setString(5, Obj.has("addressline2") ? Obj.getString("addressline2"):"");
		    pstmt.setString(6, Obj.has("state") ? Obj.getString("state"):"");
		    pstmt.setString(7, Obj.has("city") ? Obj.getString("city"):"");
		    pstmt.setString(8, Obj.has("zipcode") ? Obj.getString("zipcode"):"");
		    pstmt.setString(9, Obj.getString("userid"));
		    
			int rs = pstmt.executeUpdate();
			if (rs == 1) {
				resp.data = "success";
			} else {
				resp.data = "failure";
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}
				return resp;
			}
//this method id used to get all the user details from USERS table
	public static Response getUser(JSONObject Obj) {

			JSONArray jsonArray = new JSONArray();
			Response resp = new Response();
			try {
				resp.error = false;
				DatabaseConnection.getInstance();
				Connection conn = DatabaseConnection.getConnection();
				PreparedStatement pstmt = conn.prepareStatement(DbQuery.getUser());
				pstmt.setString(1, Obj.getString("username"));
				ResultSet rs = pstmt.executeQuery();
				
				while (rs.next()) { // looping the results

					JSONObject user = new JSONObject(); // creating a JSON for
															// each user
					user.put("username", rs.getString(1));
					user.put("gender", rs.getString(2));
					user.put("phone", rs.getString(3));
					user.put("addressline1", rs.getString(4));
					user.put("addressline2", rs.getString(5));
					user.put("state", rs.getString(6));
					user.put("city", rs.getString(7));
					user.put("zipcode", rs.getString(8));
					jsonArray.put(user);// Adding the user to JSONArray
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				resp.error = true;

			}
			resp.data = jsonArray.toString();
			return resp;
		}
		
		//This method is usd to get all the locations from location table
	public static Response getLocation() {
		JSONArray jsonArray = new JSONArray();
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(DbQuery.getAllLocations());
			int i = 0; // index to add in JSONArray
			while (rs.next()) { // looping the results

				JSONObject location = new JSONObject(); // creating a JSON for
														// each location
				location.put("LocationID", rs.getString(1));
				location.put("Locationcity", rs.getString(2));
				location.put("Locationstate", rs.getString(3));
				jsonArray.put(i, location);// Adding the location to JSONArray
				i++;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}
		resp.data = jsonArray.toString();
		return resp;
	}

	public static Response addDriver(JSONObject Obj) {
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.addDriver());
			pstmt.setString(1, Obj.getString("drivername"));
			pstmt.setString(2, Obj.getString("gender"));
			pstmt.setString(3, Obj.getString("phone"));
			pstmt.setString(4, Obj.getString("email"));
			pstmt.setString(5, Obj.getString("addressline1"));
			pstmt.setString(6, Obj.getString("addressline2"));
			pstmt.setString(7, Obj.getString("state"));
			pstmt.setString(8, Obj.getString("city"));
			pstmt.setString(9, Obj.getString("zipcode"));
			pstmt.setString(10, Obj.getString("password"));
			int rs = pstmt.executeUpdate();
			if (rs == 1) {
				resp.data = "success";
			} else {
				resp.data = "failure";
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}

		return resp;
	}

	public static Response addLocation(JSONObject Obj) {
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.addLocation());

			pstmt.setString(1, Obj.getString("locationcity"));
			pstmt.setString(2, Obj.getString("locationstate"));
			int rs = pstmt.executeUpdate();
			if (rs == 1) {
				resp.data = "success";
			} else {
				resp.data = "failure";
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}

		return resp;
	}

	public static Response addBooking(JSONObject Obj) {
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.addBooking());
			long x = (long) ((Math.random() * ((999999 - 100000) + 1)) + 100000);
			for (int i = 0; i < Obj.getJSONArray("seats").length(); i++) {
				pstmt.setString(1, x + "");
				pstmt.setString(2, Obj.getString("userid"));
				pstmt.setInt(3, Obj.getInt("tripid"));
				pstmt.setString(4, Obj.getJSONArray("seats").getString(i));
				pstmt.setString(5, Obj.getString("pickuppoint"));
				pstmt.setString(6, Obj.getString("droppoint"));
				pstmt.setDouble(7, Obj.getDouble("totalamount"));
				int rs = pstmt.executeUpdate();
				if (rs == 1) {
					resp.data = x + "";
				} else {
					resp.data = "failure";
				}
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}

		return resp;
	}

	public static Response addVehicle(JSONObject Obj) {
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.addVehicle());
			// pstmt.setString(1, Obj.getString("VehicleID"));
			pstmt.setString(1, Obj.getString("model"));
			pstmt.setString(2, Obj.getString("platenumber"));
			pstmt.setInt(3, Obj.getInt("miles"));
			pstmt.setString(4, Obj.getString("lastServiceDate"));
			pstmt.setInt(5, Obj.getInt("seats"));
			pstmt.setInt(6, Obj.getInt("r_len"));
			pstmt.setInt(7, Obj.getInt("c_len"));
			int rs = pstmt.executeUpdate();
			if (rs == 1) {
				resp.data = "success";
				for (int i = 0; i < Obj.getInt("r_len"); i++) {
					for (int j = 0; j < Obj.getInt("c_len"); j++) {
						JSONObject seat = Obj.getJSONArray("seatLayout").getJSONArray(i).getJSONObject(j);
						if (!seat.getString("type").equalsIgnoreCase("noseat"))
									addSeats(seat, Obj.getString("platenumber"));
					}

				}
			} else {
				resp.data = "failure";
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}
		return resp;
	}

	public static Response addTrips(JSONObject Obj) {
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.addTrip());
			for (int i = 0; i < Obj.getJSONArray("arrdep").length(); i++) {
				pstmt.setString(1, Obj.getString("originId"));
				pstmt.setString(2, Obj.getString("destinationId"));
				pstmt.setString(3, Obj.getJSONArray("arrdep").getJSONObject(i).getString("dep"));
				pstmt.setString(4, Obj.getJSONArray("arrdep").getJSONObject(i).getString("arr"));
				pstmt.setString(5, Obj.getString("VehicleId"));
				pstmt.setInt(6, Obj.getInt("fare"));
				pstmt.setString(7, "Scheduled");
				int rs = pstmt.executeUpdate();
				if (rs == 1) {
					resp.data = "success";
				} else {
					resp.data = "failure";
				}
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}

		return resp;
	}

	public static Response addSeats(JSONObject Obj, String VehicleId) {
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.addSeat());
			pstmt.setInt(1, Obj.getJSONObject("id").getInt("r"));
			pstmt.setInt(2, Obj.getJSONObject("id").getInt("c"));
			pstmt.setInt(3, Obj.getInt("seatno"));
			pstmt.setString(4, VehicleId);
			int rs = pstmt.executeUpdate();
			if (rs == 1) {
				resp.data = "success";
			} else {
				resp.data = "failure";
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}

		return resp;
	}

	public static Response addSchedule(JSONObject Obj) {
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.addSchedule());
			pstmt.setString(1, Obj.getString("driverid"));
			pstmt.setInt(2, Obj.getInt("tripid"));

			int rs = pstmt.executeUpdate();
			if (rs == 1) {
				resp.data = "success";
			} else {
				resp.data = "failure";
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}
return resp;
	}
	public static Response updDriver(JSONObject Obj) {
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.updDriver());

			pstmt.setString(1, Obj.getString("DriverName"));
			pstmt.setString(2, Obj.getString("Gender"));
			pstmt.setString(3, Obj.getString("Phone"));
			pstmt.setString(4, Obj.getString("Email"));
			pstmt.setString(5, Obj.getString("AddressLine1"));
			pstmt.setString(6, Obj.getString("AddressLine2"));
			pstmt.setString(7, Obj.getString("State"));
			pstmt.setString(8, Obj.getString("City"));
			pstmt.setString(9, Obj.getString("Zipcode"));
			pstmt.setString(10, Obj.getString("Leaveavail"));
			pstmt.setString(11, Obj.getString("DriverID"));

			int rs = pstmt.executeUpdate();
			if (rs == 1) {
				resp.data = "success";
			} else {
				resp.data = "failure";
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}

		return resp;
	}

	public static Response updpswd(JSONObject Obj) {
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.updPswd());
			pstmt.setString(1, Obj.getString("password"));
			pstmt.setString(2, Obj.getString("tokenid"));
			int rs = pstmt.executeUpdate();
			if (rs == 1) {
				resp.data = "success";
			} else {
				resp.data = "failure";
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}

		return resp;
	}

	public static Response updVehicle(JSONObject Obj) {
		Response resp = new Response();
		try {
			resp.error = false;
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(DbQuery.updVehicle());

			pstmt.setString(1, Obj.getString("VehicleModel"));
			pstmt.setString(2, Obj.getString("VehiclePlateno"));
			pstmt.setInt(3, Obj.getInt("MilesDriven"));
			pstmt.setString(4, Obj.getString("LastService"));
			pstmt.setString(5, Obj.getString("VehicleID"));

			int rs = pstmt.executeUpdate();
			if (rs == 1) {
				resp.data = "success";
			} else {
				resp.data = "failure";
			}
		}

		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			resp.error = true;

		}

		return resp;
	}

}
