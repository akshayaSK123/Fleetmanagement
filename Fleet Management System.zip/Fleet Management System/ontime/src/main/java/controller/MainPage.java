package controller;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainPage {
	public static String getData() {
		JSONArray jsonArray = new JSONArray();
		try {
			DatabaseConnection.getInstance();
			Connection conn = DatabaseConnection.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(DbQuery.getAllLocations());
			int i = 0; // index to add in JSONArray
			while (rs.next()) { //looping the results

				JSONObject product = new JSONObject(); //creating a JSON for each product
				product.put("City_State", rs.getString(1));
				product.put("ID", rs.getString(2));
				
				jsonArray.put(i, product);//Adding the product to JSONArray
				i++;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		}
		return jsonArray.toString();
	}

}
