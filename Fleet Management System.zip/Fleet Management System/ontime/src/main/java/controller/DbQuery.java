package controller;

public class DbQuery {
    private static final String AUTH="SELECT COUNT(*) from USERS where USERID=? && PASSWORD=md5(?);";
    private static final String ALLDRIVERS="SELECT * FROM DRIVER;";
    private static final String ALLVEHICLES="SELECT * FROM VEHICLE;";
    private static final String ALLLOCATIONS="SELECT * FROM LOCATION;";
    private static final String ALLTRIPS="SELECT * FROM TRIPS T LEFT JOIN SCHEDULES S ON T.TripID=S.TRIPID LEFT JOIN DRIVER D ON D.DRIVERID=S.DRIVERID ;";
    private static final String ALLBOOKINGS="SELECT B.BookingID,S.SEAT_NO,T.Dep,T.Arr,CONCAT(L1.LOCATIONCITY, ',',L1.LOCATIONSTATE) AS ORIGIN,CONCAT(L2.LOCATIONCITY, ',',L2.LOCATIONSTATE) AS DEST , B.TotalAmount  FROM BOOKING B,SEATS S ,TRIPS T "
    											+ "INNER JOIN  LOCATION L1  ON T.Origin = L1.LOCATIONID "
    											+ "INNER JOIN  LOCATION L2  ON T.Destination = L2.LOCATIONID "
    											+ "WHERE B.TripID = T.TripID AND B.SeatID = S.SEAT_ID AND USERID=? ";	
    
    private static final String ADDBOOKING="INSERT INTO BOOKING(BOOKINGID,USERID,TRIPID,SEATID,PICKUPPOINT,DROPPOINT,TOTALAMOUNT) VALUES(?,?,?,?,?,?,?);";
    private static final String ADDDRIVER="INSERT INTO DRIVER(DRIVERNAME,GENDER,PHONE,EMAIL,ADDRESSLINE1,ADDRESSLINE2,STATE,CITY,ZIPCODE,LEAVEAVAIL,PASSWORD) "
    		+ "VALUES(?,?,?,?,?,?,?,?,?,0,md5(?));";
    private static final String ADDVEHICLE="INSERT INTO VEHICLE(VEHICLEMODEL,VEHICLEPLATENO,"
    											+ "MILESDRIVEN,LASTSERVICE,SEATS,R_L,C_L)VALUES(?,?,?,?,?,?,?);";
    private static final String ADDSEAT="INSERT INTO SEATS(SEAT_ID,ROW_NO,COL_NO,SEAT_NO,VEHICLE_ID) VALUES(UUID(),?,?,?,?);";
    private static final String ADDLOCATION="INSERT INTO LOCATION(LOCATIONCITY,LOCATIONSTATE)VALUES(?,?);";
    private static final String ADDSCHEDULE="INSERT INTO SCHEDULES(DRIVERID,TRIPID)VALUES(?,?);";
    
    private static final String UPDPSWD="UPDATE USERS SET PASSWORD=md5(?) WHERE USERID=(SELECT USERNAME FROM RESETPASS WHERE TOKEN_KEY=?);";
    
    private static final String ADDTRIP="INSERT INTO TRIPS(ORIGIN,DESTINATION,DEP,ARR,VEHICLEID,FARE,STATUS)"
    		+ "VALUES(?,?,?,?,?,?,?);";
    
    private static final String UPDDRIVER="UPDATE DRIVER SET DRIVERNAME=?,GENDER=?,PHONE=?,EMAIL=?,ADDRESSLINE1=?,ADDRESSLINE2=?,STATE=?,CITY=?,ZIPCODE=?,LEAVEAVAIL=? WHERE DRIVERID=?;";
    private static final String UPDVEHICLE="UPDATE VEHICLE SET VEHICLEMODEL=?,VEHICLEPLATENO=?,MILESDRIVEN=?,LASTSERVICE=? WHERE VEHICLEID=?;";
    private static final String UPDUSER="UPDATE USERS SET USERNAME=?,GENDER=?,PHONE=?,ADDRESSLINE1=?,ADDRESSLINE2=?,STATE=?,CITY=?,ZIPCODE=? WHERE USERID=?;";
    private static final String GETUSER="SELECT USERNAME,GENDER,PHONE,ADDRESSLINE1,ADDRESSLINE2,STATE,CITY,ZIPCODE,USERID FROM USERS WHERE USERID=?;";
    //Trip Planner 
    private static final String SEARCHTRIP=" SELECT * FROM TRIPS T,VEHICLE R WHERE T.VehicleId = R.VEHICLEPLATENO AND ORIGIN =? AND DESTINATION = ?"
    								+ " AND DEP > ? AND DEP < ?";
    
    
    private static final String VIEW_SEATS="SELECT * FROM SEATS WHERE VEHICLE_ID= ?";
    private static final String BOOKED_SEATS="SELECT SeatID FROM Booking WHERE TRIPID= ?";
    private static final String ADMIN="SELECT COUNT(*) from ADMININFO where USERNAME=? && PASSWORD=md5(?);";
    //Reset Password
    private static final String VALID_USER = "SELECT COUNT(*) FROM USERS WHERE USERID= ?";
    private static final String RESET_PASS ="INSERT INTO RESETPASS(USERNAME,TOKEN_KEY,REQ_TIME,ACTIVE) VALUES (?,?,?,'YES')";
    private static final String CHECK_TOKEN ="UPDATE RESETPASS SET ACTIVE='NO' WHERE TOKEN_KEY=? AND ACTIVE='YES'" ;
    private static final String SIGNIN="INSERT INTO USERS(USERID,PASSWORD)"
    		+ "VALUES(?,md5(?));";
    
    public static String register() {
        return SIGNIN;
    }
    
    public static String adminlogin() {
        return ADMIN;
    }
    
    public static String getAUTH() {
        return AUTH;
    }
    public static String getalldrivers() {
        return ALLDRIVERS;
    }
    public static String getAllLocations() {
        return ALLLOCATIONS;
    }
    public static String getallVehicles() {
        return ALLVEHICLES;
    }
   
    public static String getallTrips() {
        return ALLTRIPS;
    }
    public static String getBookings() {
        return ALLBOOKINGS;
    }
    public static String getUser() {
        return GETUSER;
    }
    
    
        
    public static String addDriver() {
        return ADDDRIVER;
    }
    public static String addSeat() {
        return ADDSEAT;
    }
    public static String addTrip() {
        return ADDTRIP;
    }
    public static String addVehicle() {
        return ADDVEHICLE;
    }
    
    public static String addBooking() {
        return ADDBOOKING;
    }
    
    public static String addLocation() {
        return ADDLOCATION;
    }
   
    public static String addSchedule() {
        return ADDSCHEDULE;
    }
   
    
    public static String updDriver() {
        return UPDDRIVER;
    }
    public static String updVehicle() {
        return UPDVEHICLE;
    }
    
    public static String updUsers() {
        return UPDUSER;
    }
    public static String updPswd() {
        return UPDPSWD;
    }
    
    
   //TripPlanner - Getters
    public static String searchTrip() {
        return SEARCHTRIP;
    }
    //Seats
    public static String getViewSeats() {
        return VIEW_SEATS;
    }
    public static String getBookedSeats() {
        return BOOKED_SEATS;
    }
    //Forgot Password 
    public static String validUser() {
        return VALID_USER;
    }
    public static String getresetPass() {
        return RESET_PASS;
    }
    public static String checkToken() {
        return CHECK_TOKEN;
    }
}