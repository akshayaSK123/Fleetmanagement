package controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
	
	    private static DatabaseConnection instance;
	    private static Connection connection;
	    private String url = "jdbc:mysql://localhost:3306/ontime";
	    private String databaseDriver = "com.mysql.cj.jdbc.Driver";
	    private String username = "root";
	    private String password = "root";


	    private DatabaseConnection() throws SQLException {
	        try {
	            Class.forName(databaseDriver);
	            this.connection = DriverManager.getConnection(url, username, password);
	        } catch (ClassNotFoundException ex) {
	            System.out.println("Database Connection Creation Failed : " + ex.getMessage());
	        }
	    }

	    //method to get database connection
	    public static Connection getConnection() {
	        return connection;
	    }

	    //static method to create instance of Singleton class
	    public static DatabaseConnection getInstance() throws SQLException {
	        if (instance == null) {
	            instance = new DatabaseConnection();
	        } else if (instance.getConnection().isClosed()) {
	            instance = new DatabaseConnection();
	        }
	        return instance;
	    }

	    //static method to close connection
	    public static void closeConnection() throws SQLException {
	        try {
	            connection.close();
	        }catch (Exception e)
	        {
	            System.out.println("Close connection failed  : " + e.getMessage());
	        }
	    }
	}
