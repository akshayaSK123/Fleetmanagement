package models;

public class Response {
	    public Boolean error;
	    public Boolean session;
	    public String data;

}
