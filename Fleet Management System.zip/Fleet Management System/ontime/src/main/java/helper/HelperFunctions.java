package helper;

import javax.servlet.http.Cookie;
import com.sendgrid.*;
import com.sendgrid.helpers.mail.Mail;
import com.sendgrid.helpers.mail.objects.Content;
import com.sendgrid.helpers.mail.objects.Email;

import java.io.IOException;


public class HelperFunctions {
	public static Boolean checkAuthCookie(Cookie[] cookies) {
		Boolean session = false;
		for (Cookie cookie : cookies) {
			if (cookie.getName().equals("auth") && cookie.getValue().equals("true"))
				return true;
		}
		return session;


	}
	public static Boolean checkAdminCookie(Cookie[] cookies) {
		Boolean session = false;
		for (Cookie cookie : cookies) {
			if (cookie.getName().equals("adminSession") && cookie.getValue().equals("true"))
				return true;
		}
		return session;


	}

	public static void SendResetMail(String Email,String Link) {
	    Email from = new Email("no-reply@ontime.com");
	    String subject = "Reset Password - Ontime Account";
	    Email to = new Email(Email);
	    Content content = new Content("text/plain", "Password Reset Link : http://localhost:4200/reset/"+Link);
	    Mail mail = new Mail(from, subject, to, content);

	    SendGrid sg = new SendGrid("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");
	    Request request = new Request();
	    try {
	      request.setMethod(Method.POST);
	      request.setEndpoint("mail/send");
	      request.setBody(mail.build());
	      Response response = sg.api(request);
	      System.out.println(response.getStatusCode());
	      System.out.println(response.getBody());
	      System.out.println(response.getHeaders());
	    } catch (IOException ex) {
	     System.out.print("Error "+ex.toString());
	    }
	}

}
