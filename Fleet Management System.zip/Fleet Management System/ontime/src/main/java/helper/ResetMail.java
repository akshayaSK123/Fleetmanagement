package helper;

public class ResetMail {
public static String resetMail = "";

}
